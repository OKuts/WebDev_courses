document.querySelector('.mobile').onmouseover = () => {
    document.querySelector('.down-menu').style.left = 0;
}