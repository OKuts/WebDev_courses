$('.slider').slick({
    // autoplay:true,
    autoplaySpeed: 1000,
    dots: true,
    //dotsClass:rectangle
    //slidesToShow:3,
    //slidesToScroll:1,
    //slidesPerRow:3
    //vertical: true
});