module.exports = {
    b: 2,
    c: 'hi'
}