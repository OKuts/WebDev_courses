module.exports = function randomInt(a, b) {
    return a + Math.round(Math.random() * (b - a));
}

