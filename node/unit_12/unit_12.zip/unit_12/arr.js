module.exports = [
    { id: 24, name: 'Test', age: 23 },
    { id: 34, name: 'User', age: 33 }
];