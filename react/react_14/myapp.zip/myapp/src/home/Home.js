import React from 'react';
// import './Nav.css';
class Home extends React.Component {
    render() {
        return (
            <div className="App" >
                <h1>Home</h1>
            </div>
        );
    }
}


export default Home;