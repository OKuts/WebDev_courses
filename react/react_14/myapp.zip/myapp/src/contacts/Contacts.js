import React from 'react';
import './Contacts.css';
class Contacts extends React.Component {
    render() {
        return (
            <div  >
                <div className="container">
                    <h1>Contacts</h1>
                </div>
            </div>
        );
    }
}


export default Contacts;