import React from 'react';
// import './Nav.css';
class My404 extends React.Component {
    render() {
        return (
            <div>
                <h1>404</h1>
            </div>
        );
    }
}


export default My404;