class Man {
    constructor(name, height, weight, age, sex, passport, eye) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.age = age;
        this.sex = sex;
        this.passport = passport;
        this.eye = eye
    }
}