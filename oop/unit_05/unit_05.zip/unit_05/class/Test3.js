class Test3 extends Test2 {
}